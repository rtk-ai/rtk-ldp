# 3 SkillsBench tasks, K=6 — sweep 20260807

Paired A/B sweep, RTK ON vs OFF, 3 tasks. Tables below are the output of `cost_pooled.py`; per-trial values in `data/per_trial.csv`, per-task medians in `data/compare_sweep.txt`.

```
========================================================================
POOLED COST (RTK ON vs OFF, reward-agnostic)   results/sweep-20260807-072640
========================================================================

task                           OFF n  ON n  OFF mean  ON mean   Δmean   Δmed
  dialogue-parser                  5     6      0.36     0.32    -13%   -15%
  fix-build-google-auto            5     5      2.36     2.50     +6%   -24%
  simpo-code-reproduction          6     5      0.92     0.91     -1%   -11%

------------------------------------------------------------------------
clean cost trials: OFF=16  ON=16   (3 task-pairs)
median of per-task MEAN   deltas = -1.1%
median of per-task MEDIAN deltas = -15.1%

POOLED normalized (1.0 = each task's OFF mean, all trials):
  OFF mean = 1.000   ON mean = 0.968   ->  ON -3.2%   permutation p = 0.801
```
